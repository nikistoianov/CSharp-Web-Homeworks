﻿namespace SoftUni.WebServer.Mvc.Attributes.HttpMethods
{
    public class HttpPostAttribute : HttpMethodAttribute
    {
        public override bool IsValid(string requestMethod)
        {
            return requestMethod.ToUpper() == "POST";
        }
    }
}
