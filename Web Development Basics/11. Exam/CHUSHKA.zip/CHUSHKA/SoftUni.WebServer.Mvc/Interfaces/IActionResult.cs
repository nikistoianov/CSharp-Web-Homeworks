﻿namespace SoftUni.WebServer.Mvc.Interfaces
{
    public interface IActionResult
    {
        string Invoke();
    }
}
