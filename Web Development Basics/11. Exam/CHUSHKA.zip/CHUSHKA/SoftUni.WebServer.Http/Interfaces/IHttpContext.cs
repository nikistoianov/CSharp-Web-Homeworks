﻿namespace SoftUni.WebServer.Http.Interfaces
{
    public interface IHttpContext
    {
        IHttpRequest Request { get; }
    }
}
